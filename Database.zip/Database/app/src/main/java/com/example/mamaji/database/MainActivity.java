package com.example.mamaji.database;

import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnSignIN,btnSignUp;
    LoginDataBaseAdapter loginDataBaseAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loginDataBaseAdapter=new LoginDataBaseAdapter(this);
        loginDataBaseAdapter=loginDataBaseAdapter.open();

        btnSignIN=findViewById(R.id.buttonSignIN);
        btnSignUp=findViewById(R.id.buttonSignUP);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentSignUP=new Intent(getApplicationContext(),Signup.class);
                startActivity(intentSignUP);
            }
        });
    }
    public void SignIn(View V)
    {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.login);
        dialog.setTitle("login");

        final EditText editTextUserName=dialog.findViewById(R.id.editTextUserNameToLogin);
        final EditText editTextPassword=dialog.findViewById(R.id.editTextPasswordToLogin);
        final EditText editPhone=dialog.findViewById(R.id.editPhoneToLogin);

        Button btnSignIn=dialog.findViewById(R.id.buttonSignIn);

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName=editTextUserName.getText().toString();
                String password=editTextPassword.getText().toString();
                String phone=editPhone.getText().toString();

                String storedPassword=loginDataBaseAdapter.getSingleEntry(userName);

                if(password.equals(storedPassword))
                {
                    Intent in = new Intent(MainActivity.this, LoggedData.class);
                    in.putExtra("name",userName);
                    in.putExtra("password",password);
                    in.putExtra("phone",phone);
                    startActivity(in);

                    Toast.makeText(MainActivity.this,"Congrats : LOgin Successful",Toast.LENGTH_LONG).show();
                    dialog.dismiss();
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Congrats : Username and password do not match",Toast.LENGTH_LONG).show();

                }
            }
        });
       dialog.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        loginDataBaseAdapter.close();
    }
}
