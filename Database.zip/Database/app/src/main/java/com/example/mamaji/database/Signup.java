package com.example.mamaji.database;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Signup extends AppCompatActivity {
    EditText editTextUserName,editTextPassword,editTextConfirmPassword,editPhone;
    Button btnCreateAccount;

    LoginDataBaseAdapter loginDataBaseAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        loginDataBaseAdapter= new LoginDataBaseAdapter(this);
        loginDataBaseAdapter=loginDataBaseAdapter.open();

        editTextConfirmPassword=findViewById(R.id.editTextConfirmPassword);
        editTextPassword=findViewById(R.id.editTextPassword);
        editTextUserName=findViewById(R.id.editTextUserName);
        editPhone=findViewById(R.id.editPhone);

        btnCreateAccount=findViewById(R.id.buttonCreateAccount);
        btnCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName=editTextUserName.getText().toString();
                String password=editTextPassword.getText().toString();
                String confirmPassword=editTextConfirmPassword.getText().toString();
                String Phone=editPhone.getText().toString();

                if(userName.equals("") || password.equals("") || confirmPassword.equals("") || Phone.equals(""))
                {
                    Toast.makeText(getApplicationContext(),"Field Vacant", Toast.LENGTH_LONG).show();
                    return;
                }

                if(!password.equals(confirmPassword))
                {
                    Toast.makeText(getApplicationContext(), "Password does not match", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    loginDataBaseAdapter.insertEntry(userName,password,Phone);
                    Toast.makeText(getApplicationContext(),"Account Successfully created",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
       loginDataBaseAdapter.close();
    }
}
