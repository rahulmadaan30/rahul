package com.example.mamaji.sharedpreferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    SharedPreferences sharedpreferences;
    EditText etName,etEmail;
    public static final String mypreference = "mypref";
    public static final String Name = "name";
    public static final String Email = "email";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);

        sharedpreferences = getSharedPreferences(mypreference, Context.MODE_PRIVATE);
        if(sharedpreferences.contains(Name)) {
            etName.setText(sharedpreferences.getString(Name,""));
        }
        if (sharedpreferences.contains(Email)){
            etEmail.setText(sharedpreferences.getString(Email,""));
        }
    }
    public void Save(View view){
        String n = etName.getText().toString();
        String e = etEmail.getText().toString();

        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(Name, n);
        editor.putString(Email, e);
        editor.commit();
    }

    public void clear(View view){
        etEmail.setText("");
        etName.setText("");
    }

    public void Get(View view) {
        sharedpreferences = getSharedPreferences(mypreference,Context.MODE_PRIVATE);

        if (sharedpreferences.contains(Name)) {
            etName.setText(sharedpreferences.getString(Name,""));
        }

        if (sharedpreferences.contains(Email)) {
            etEmail.setText(sharedpreferences.getString(Email,""));
        }
    }
}
