package com.example.mamaji.gridview;

import android.content.Context;
import android.graphics.drawable.LayerDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

public class ImageAdapter extends BaseAdapter{
        private Context mContext;
        private LayoutInflater inflater;
        private ImageView imageView;

        public ImageAdapter(Context c)
        {
            mContext = c;
            inflater = LayoutInflater.from(mContext);
        }

        public int getCount()
        {
            return mThumbsIds.length;
        }
        public Object getItem(int position)
        {
            return null;
        }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

            if(null== convertView) {
                convertView = inflater.inflate(R.layout.grid_row,parent,false);
                imageView = (ImageView) convertView.findViewById(R.id.iv_grid);
            }

            Picasso.with(mContext)
                    .load(mThumbsIds[position])
                    .into(imageView);
        return convertView;
    }

    public Integer[] mThumbsIds = {R.mipmap.ic_launcher,R.mipmap.ic_launcher_round,R.mipmap.ic_launcher,R.mipmap.ic_launcher};

}
