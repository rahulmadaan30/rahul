package com.example.mamaji.alertwithmultiplechoice;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button b;
    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b = findViewById(R.id.addItem);
        tv = findViewById(R.id.tv);
       b.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

               String[] colors = new String[]{"Red", "green", "blue", "yellow", "olive"};

               final boolean[] checkedColors = new boolean[]{
                       false,
                       false,
                       false,
                       false,
                       false
               };

               final List<String> colorList = Arrays.asList(colors);

               builder.setMultiChoiceItems(colors, checkedColors,
                       new DialogInterface.OnMultiChoiceClickListener() {
                           @Override
                           public void onClick(DialogInterface dialogInterface, int which, boolean isChecked) {

                               checkedColors[which] = isChecked;

                               String currentItem = colorList.get(which);
                           }
                       });

               builder.setCancelable(false);
               builder.setTitle("your preferred colors?");

               builder.setPositiveButton("OK",
                       new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               tv.setText("your preferref colors.... \n");
                               for (int i = 0; i < checkedColors.length; i++) {
                                   boolean checked = checkedColors[i];
                                   if (checked) {
                                       tv.setText(tv.getText() + colorList.get(i) + ",");
                                   }
                               }
                           }
                       });
               builder.setNegativeButton("no", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialog, int which) {

                   }
               });
               builder.setNeutralButton("cancel", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialogInterface, int i) {

                   }

               });
               AlertDialog dialog = builder.create();
               dialog.show();
           }
       });

    }
}
