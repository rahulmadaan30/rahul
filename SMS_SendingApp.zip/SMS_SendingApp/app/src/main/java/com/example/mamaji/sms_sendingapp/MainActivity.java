package com.example.mamaji.sms_sendingapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
 Button send;
 EditText phone_Number,message;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        send = findViewById(R.id.Send_msg_Btn);
        phone_Number = findViewById(R.id.EditText_PhoneNumber);
        message = findViewById(R.id.MainActivity_Message);
        send.setOnClickListener(this);
    }
    public void onClick(View v){
       String phone_Num = phone_Number.getText().toString();
       String send_msg = message.getText().toString();
       try {
           SmsManager sms = SmsManager.getDefault();
           sms.sendTextMessage(phone_Num,"",send_msg,null,null);
       } catch (Exception e) {
           Toast.makeText(this,"Sms not sent",Toast.LENGTH_SHORT).show();
           e.printStackTrace();
       }
     }

}
